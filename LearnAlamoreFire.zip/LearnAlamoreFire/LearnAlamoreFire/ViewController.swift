//
//  ViewController.swift
//  LearnAlamoreFire
//
//  Created by Pham Tung on 8/26/19.
//  Copyright © 2019 Pham Tung. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
Alamofire.request("https://my-json-server.typicode.com/typicode/demo/posts").responseJSON
        {
            response in
            if let json = response.result.value {
                print("JSON: \(json)")
            }
        }
    }


}

